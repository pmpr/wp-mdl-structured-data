<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106b138870             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Plugin; use Pmpr\Module\StructuredData\Container; class Woocommerce extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('woocommerce_structured_data_product', '__return_empty_array'); } }
