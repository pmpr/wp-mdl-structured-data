<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\x61\160\x70\154\x69\x63\141\x74\151\x6f\156\x2f\x6c\x64\x2b\152\163\157\156"; const ocmiuacywmgycowk = "\163\x74\162\x75\x63\x74\165\162\x65\144\x5f\144\x61\164\x61\x5f"; }
