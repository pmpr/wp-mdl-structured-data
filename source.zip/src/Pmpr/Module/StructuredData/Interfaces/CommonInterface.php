<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57cac70982             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\160\x6c\x69\x63\x61\x74\x69\x6f\156\57\x6c\144\x2b\x6a\163\x6f\x6e"; const ocmiuacywmgycowk = "\x73\164\x72\x75\143\x74\x75\162\x65\x64\137\x64\x61\x74\x61\137"; }
