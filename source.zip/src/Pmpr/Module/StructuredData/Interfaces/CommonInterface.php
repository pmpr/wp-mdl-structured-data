<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\x61\x70\160\x6c\x69\x63\x61\x74\151\157\x6e\x2f\154\x64\x2b\152\x73\x6f\x6e"; const ocmiuacywmgycowk = "\x73\x74\162\165\x63\x74\165\x72\x65\x64\x5f\144\x61\x74\141\x5f"; }
