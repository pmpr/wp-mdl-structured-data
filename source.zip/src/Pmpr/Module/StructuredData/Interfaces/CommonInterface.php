<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\160\x6c\151\x63\x61\164\151\157\x6e\57\154\x64\53\x6a\x73\157\x6e"; const ocmiuacywmgycowk = "\163\164\x72\x75\143\x74\165\162\x65\x64\x5f\x64\x61\164\141\137"; }
