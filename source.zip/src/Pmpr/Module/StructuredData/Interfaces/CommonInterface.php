<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\x61\x70\160\x6c\x69\x63\x61\164\151\157\156\57\154\x64\53\x6a\163\157\x6e"; const ocmiuacywmgycowk = "\163\164\162\165\x63\164\x75\162\x65\144\137\144\x61\164\x61\137"; }
