<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a583b359559             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\x70\154\x69\x63\141\x74\151\157\156\x2f\154\144\x2b\x6a\x73\x6f\x6e"; const ocmiuacywmgycowk = "\163\x74\x72\x75\x63\164\x75\x72\145\x64\137\144\x61\x74\141\137"; }
