<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\x70\x6c\x69\143\141\x74\x69\x6f\156\57\x6c\144\x2b\x6a\x73\157\x6e"; const ocmiuacywmgycowk = "\163\x74\x72\165\x63\164\165\162\145\144\137\144\x61\x74\141\x5f"; }
