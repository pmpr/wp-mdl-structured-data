<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\x61\160\160\x6c\151\x63\141\164\151\x6f\x6e\x2f\x6c\144\x2b\152\163\157\x6e"; const ocmiuacywmgycowk = "\x73\x74\162\165\143\164\x75\162\x65\144\137\144\141\x74\141\x5f"; }
