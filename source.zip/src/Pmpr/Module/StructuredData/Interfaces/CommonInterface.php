<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\160\x6c\151\143\x61\164\151\x6f\156\57\154\144\53\152\163\x6f\156"; const ocmiuacywmgycowk = "\x73\x74\162\x75\x63\x74\x75\162\x65\x64\x5f\x64\141\x74\x61\137"; }
