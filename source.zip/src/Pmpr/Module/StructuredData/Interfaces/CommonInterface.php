<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56fbc5c29             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\x61\x70\160\154\x69\143\141\x74\151\157\x6e\57\x6c\x64\x2b\152\x73\157\x6e"; const ocmiuacywmgycowk = "\163\x74\x72\x75\x63\x74\165\162\x65\x64\137\144\x61\x74\x61\137"; }
