<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\160\x6c\x69\x63\x61\x74\x69\157\x6e\x2f\154\x64\x2b\x6a\x73\157\156"; const ocmiuacywmgycowk = "\163\164\162\x75\143\x74\x75\162\x65\144\x5f\144\x61\164\141\x5f"; }
