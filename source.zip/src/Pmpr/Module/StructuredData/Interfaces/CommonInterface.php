<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\x70\154\151\x63\x61\x74\151\x6f\x6e\57\x6c\x64\x2b\152\163\x6f\x6e"; const ocmiuacywmgycowk = "\163\x74\x72\x75\x63\x74\x75\x72\145\x64\x5f\x64\x61\164\x61\137"; }
