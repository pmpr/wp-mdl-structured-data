<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\x70\x6c\151\x63\x61\x74\x69\157\x6e\x2f\x6c\144\x2b\x6a\x73\x6f\156"; const ocmiuacywmgycowk = "\163\164\x72\165\143\164\165\162\145\144\137\x64\141\x74\x61\137"; }
