<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\x70\154\x69\x63\x61\x74\151\157\x6e\57\x6c\x64\53\152\x73\x6f\x6e"; const ocmiuacywmgycowk = "\x73\164\x72\x75\143\164\165\x72\145\x64\137\144\141\x74\x61\x5f"; }
