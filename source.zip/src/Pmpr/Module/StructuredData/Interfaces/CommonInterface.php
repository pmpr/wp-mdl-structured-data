<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\160\154\x69\x63\141\164\x69\x6f\x6e\x2f\x6c\x64\x2b\x6a\163\x6f\156"; const ocmiuacywmgycowk = "\x73\164\x72\x75\143\164\x75\162\x65\x64\x5f\144\141\164\x61\137"; }
