<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\160\x70\x6c\x69\143\x61\164\x69\x6f\x6e\57\x6c\x64\53\x6a\x73\157\156"; const ocmiuacywmgycowk = "\163\x74\x72\165\143\164\x75\162\145\144\137\x64\x61\x74\x61\137"; }
