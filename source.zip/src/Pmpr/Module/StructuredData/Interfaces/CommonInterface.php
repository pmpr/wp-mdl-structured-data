<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\160\x6c\x69\143\141\x74\151\157\156\x2f\x6c\x64\x2b\x6a\x73\157\x6e"; const ocmiuacywmgycowk = "\x73\164\x72\x75\143\164\165\x72\145\x64\137\144\x61\164\x61\x5f"; }
