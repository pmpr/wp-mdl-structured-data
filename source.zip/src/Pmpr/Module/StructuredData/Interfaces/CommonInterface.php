<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Interfaces; interface CommonInterface { const amgecouwceeaomww = "\141\x70\x70\154\151\x63\141\164\x69\x6f\x6e\x2f\154\x64\x2b\x6a\x73\157\x6e"; const ocmiuacywmgycowk = "\x73\x74\162\x75\143\164\165\162\x65\144\x5f\144\x61\x74\x61\x5f"; }
