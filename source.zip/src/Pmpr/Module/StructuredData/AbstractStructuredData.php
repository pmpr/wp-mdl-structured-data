<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a583b359559             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\x64\x53\x63\x68\145\155\x61"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\167\x70\x5f\146\157\157\164\x65\162", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
