<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\144\144\x53\143\150\145\155\x61"))) { goto ewscugeuicukkycc; } $this->qcsmikeggeemccuu("\x77\x70\137\x66\x6f\x6f\164\145\x72", [$this, $qgciuiagkkguykgs], 9999); ewscugeuicukkycc: } }
