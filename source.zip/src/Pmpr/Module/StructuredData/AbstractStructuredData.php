<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\x53\143\x68\145\x6d\141"))) { goto cecuyayqoioasumi; } $this->qcsmikeggeemccuu("\x77\160\137\x66\x6f\x6f\164\145\x72", [$this, $qgciuiagkkguykgs], 9999); cecuyayqoioasumi: } }
