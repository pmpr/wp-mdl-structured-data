<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\x53\143\x68\145\x6d\x61"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\x77\x70\x5f\146\x6f\x6f\x74\x65\162", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
