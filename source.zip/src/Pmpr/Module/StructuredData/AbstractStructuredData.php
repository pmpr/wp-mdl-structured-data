<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\x64\123\x63\x68\145\155\141"))) { goto ewscugeuicukkycc; } $this->qcsmikeggeemccuu("\x77\160\137\146\x6f\x6f\164\x65\x72", [$this, $qgciuiagkkguykgs], 9999); ewscugeuicukkycc: } }
