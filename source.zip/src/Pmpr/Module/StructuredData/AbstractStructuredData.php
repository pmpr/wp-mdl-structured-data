<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\144\123\x63\x68\145\155\141"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\x77\x70\x5f\146\157\x6f\x74\145\162", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
