<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\144\123\x63\x68\145\155\x61"))) { goto omugkkesagcyagmk; } $this->qcsmikeggeemccuu("\167\160\x5f\146\x6f\x6f\x74\x65\x72", [$this, $qgciuiagkkguykgs], 9999); omugkkesagcyagmk: } }
