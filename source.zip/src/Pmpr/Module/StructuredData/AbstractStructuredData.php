<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5eca5e30b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\123\143\150\145\x6d\141"))) { goto wkwamkgkwykeqkec; } $this->qcsmikeggeemccuu("\x77\160\137\146\x6f\x6f\x74\x65\162", [$this, $qgciuiagkkguykgs], 9999); wkwamkgkwykeqkec: } }
