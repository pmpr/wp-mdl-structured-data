<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\x64\123\143\x68\x65\x6d\x61"))) { goto sguskaeaaqcagqgc; } $this->qcsmikeggeemccuu("\167\160\137\146\x6f\157\x74\145\162", [$this, $qgciuiagkkguykgs], 9999); sguskaeaaqcagqgc: } }
