<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\144\144\123\x63\150\145\x6d\x61"))) { goto cecuyayqoioasumi; } $this->qcsmikeggeemccuu("\x77\160\x5f\x66\x6f\157\164\x65\162", [$this, $qgciuiagkkguykgs], 9999); cecuyayqoioasumi: } }
