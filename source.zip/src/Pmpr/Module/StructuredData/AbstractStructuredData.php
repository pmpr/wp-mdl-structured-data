<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57cac70982             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\144\x53\x63\150\x65\x6d\141"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\x77\x70\137\146\157\157\x74\145\x72", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
