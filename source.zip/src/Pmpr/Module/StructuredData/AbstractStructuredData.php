<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\x64\123\143\x68\145\155\141"))) { goto ewscugeuicukkycc; } $this->qcsmikeggeemccuu("\x77\160\137\146\x6f\157\164\x65\x72", [$this, $qgciuiagkkguykgs], 9999); ewscugeuicukkycc: } }
