<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\x64\123\143\150\x65\155\141"))) { goto ewscugeuicukkycc; } $this->qcsmikeggeemccuu("\167\x70\137\146\157\157\164\145\162", [$this, $qgciuiagkkguykgs], 9999); ewscugeuicukkycc: } }
