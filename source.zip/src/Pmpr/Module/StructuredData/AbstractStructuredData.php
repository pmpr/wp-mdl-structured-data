<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e686aa44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\144\144\x53\x63\150\x65\x6d\x61"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\x77\x70\x5f\x66\157\x6f\164\145\162", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
