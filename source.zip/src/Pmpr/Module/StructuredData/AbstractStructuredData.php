<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\144\123\143\150\x65\155\141"))) { goto ocywegekakimmwcq; } $this->qcsmikeggeemccuu("\167\x70\x5f\146\157\157\x74\x65\x72", [$this, $qgciuiagkkguykgs], 9999); ocywegekakimmwcq: } }
