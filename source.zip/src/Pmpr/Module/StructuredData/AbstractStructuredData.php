<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\144\123\143\x68\x65\155\x61"))) { goto cecuyayqoioasumi; } $this->qcsmikeggeemccuu("\x77\x70\x5f\x66\157\x6f\164\145\x72", [$this, $qgciuiagkkguykgs], 9999); cecuyayqoioasumi: } }
