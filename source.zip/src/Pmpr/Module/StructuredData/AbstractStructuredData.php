<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\144\123\143\x68\x65\x6d\141"))) { goto sguskaeaaqcagqgc; } $this->qcsmikeggeemccuu("\167\x70\137\146\x6f\x6f\164\x65\x72", [$this, $qgciuiagkkguykgs], 9999); sguskaeaaqcagqgc: } }
