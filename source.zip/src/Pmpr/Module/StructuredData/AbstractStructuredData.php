<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56fbc5c29             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\x64\123\143\150\145\155\141"))) { goto cecuyayqoioasumi; } $this->qcsmikeggeemccuu("\167\160\x5f\146\x6f\x6f\x74\x65\162", [$this, $qgciuiagkkguykgs], 9999); cecuyayqoioasumi: } }
