<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\x64\123\143\150\x65\x6d\x61"))) { goto omugkkesagcyagmk; } $this->qcsmikeggeemccuu("\x77\x70\137\x66\x6f\157\x74\145\162", [$this, $qgciuiagkkguykgs], 9999); omugkkesagcyagmk: } }
