<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4bc5b7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; use Pmpr\Module\StructuredData\Traits\SchemaPopulatorTrait; abstract class AbstractStructuredData extends Container { use SchemaPopulatorTrait; const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, 'addSchema')) { $this->qcsmikeggeemccuu('wp_footer', [$this, $qgciuiagkkguykgs], 9999); } } }
