<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5905a7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\x64\123\143\x68\x65\155\x61")) { $this->qcsmikeggeemccuu("\x77\160\137\146\157\x6f\x74\x65\x72", [$this, $qgciuiagkkguykgs], 9999); } } }
