<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\123\143\150\x65\155\141"))) { goto ousiuuwgwkiyikyq; } $this->qcsmikeggeemccuu("\167\160\137\x66\157\x6f\164\145\x72", [$this, $qgciuiagkkguykgs], 9999); ousiuuwgwkiyikyq: } }
