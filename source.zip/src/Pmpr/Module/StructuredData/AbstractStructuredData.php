<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c2a7289             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\x64\x53\x63\150\x65\x6d\x61")) { $this->qcsmikeggeemccuu("\167\160\x5f\146\157\x6f\164\145\162", [$this, $qgciuiagkkguykgs], 9999); } } }
