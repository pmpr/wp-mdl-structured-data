<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Action; use Pmpr\Module\StructuredData\Schema\Intangible\EntryPoint; use Pmpr\Module\StructuredData\Schema\Thing; class Action extends Thing { protected ?EntryPoint $target = null; public function oockkiieqcwiocga(?EntryPoint $ccamueccusigaaio) : Action { $this->target = $ccamueccusigaaio; return $this; } public function squsacgomqgkakaw() : EntryPoint { return $this->target; } }
