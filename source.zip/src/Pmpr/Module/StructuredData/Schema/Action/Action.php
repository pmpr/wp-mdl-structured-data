<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c2a7289             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Action; use Pmpr\Module\StructuredData\Schema\Intangible\EntryPoint; use Pmpr\Module\StructuredData\Schema\Thing; class Action extends Thing { protected ?EntryPoint $target = null; public function oockkiieqcwiocga(?EntryPoint $ccamueccusigaaio) : Action { $this->target = $ccamueccusigaaio; return $this; } public function squsacgomqgkakaw() : EntryPoint { return $this->target; } }
