<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; use Pmpr\Module\StructuredData\Schema\CreativeWork\CreativeWork; class WebPageElement extends CreativeWork { protected $cssSelector; public function __construct($goiqeyeaqmicqiky = true) { $this->isGlobal = true; parent::__construct($goiqeyeaqmicqiky); } public function ckqasoiiqqiuueki(?string $mcgyeccsyakkwsgu) : self { $this->cssSelector = $mcgyeccsyakkwsgu; return $this; } }
