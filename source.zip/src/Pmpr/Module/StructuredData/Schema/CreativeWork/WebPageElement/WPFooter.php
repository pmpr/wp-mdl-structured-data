<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e686aa44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iwekmyyccgiyuecc; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\137\146\157\x6f\x74\145\x72"); iwekmyyccgiyuecc: parent::__construct($goiqeyeaqmicqiky); } }
