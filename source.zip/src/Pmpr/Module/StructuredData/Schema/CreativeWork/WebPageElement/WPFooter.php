<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto egasokooagakisiy; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\x65\x5f\x66\157\157\164\145\162"); egasokooagakisiy: parent::__construct($goiqeyeaqmicqiky); } }
