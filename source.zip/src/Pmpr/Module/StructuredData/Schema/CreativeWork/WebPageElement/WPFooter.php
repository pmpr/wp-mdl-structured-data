<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5eca5e30b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto uguigkcmukuouway; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\x66\157\157\x74\x65\162"); uguigkcmukuouway: parent::__construct($goiqeyeaqmicqiky); } }
