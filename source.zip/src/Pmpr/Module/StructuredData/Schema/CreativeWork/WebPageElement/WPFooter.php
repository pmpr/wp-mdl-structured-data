<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto soqqemyioggmoakg; } $this->ckqasoiiqqiuueki("\43\x73\151\x74\145\137\146\x6f\x6f\x74\x65\162"); soqqemyioggmoakg: parent::__construct($goiqeyeaqmicqiky); } }
