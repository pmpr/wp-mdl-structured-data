<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56fbc5c29             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto gimmuoqwckiseaik; } $this->ckqasoiiqqiuueki("\43\x73\151\164\145\137\146\157\157\164\145\162"); gimmuoqwckiseaik: parent::__construct($goiqeyeaqmicqiky); } }
