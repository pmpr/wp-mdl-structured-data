<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto eeqesooyqagwawae; } $this->ckqasoiiqqiuueki("\43\163\x69\164\145\137\146\157\x6f\x74\x65\162"); eeqesooyqagwawae: parent::__construct($goiqeyeaqmicqiky); } }
