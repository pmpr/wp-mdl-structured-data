<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto wgewmqieuamsoayy; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\x5f\146\157\157\x74\x65\162"); wgewmqieuamsoayy: parent::__construct($goiqeyeaqmicqiky); } }
