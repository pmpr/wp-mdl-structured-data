<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto soqqemyioggmoakg; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\146\x6f\x6f\164\145\x72"); soqqemyioggmoakg: parent::__construct($goiqeyeaqmicqiky); } }
