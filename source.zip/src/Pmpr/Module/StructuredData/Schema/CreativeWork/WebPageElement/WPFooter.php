<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto gimmuoqwckiseaik; } $this->ckqasoiiqqiuueki("\43\x73\151\164\145\x5f\x66\157\157\x74\145\x72"); gimmuoqwckiseaik: parent::__construct($goiqeyeaqmicqiky); } }
