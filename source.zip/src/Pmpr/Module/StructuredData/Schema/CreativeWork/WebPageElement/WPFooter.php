<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto egasokooagakisiy; } $this->ckqasoiiqqiuueki("\43\x73\x69\x74\145\137\x66\x6f\x6f\164\x65\162"); egasokooagakisiy: parent::__construct($goiqeyeaqmicqiky); } }
