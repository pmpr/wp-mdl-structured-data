<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto coywmiyqgsweuiic; } $this->ckqasoiiqqiuueki("\43\x73\151\x74\x65\137\x66\157\157\164\x65\x72"); coywmiyqgsweuiic: parent::__construct($goiqeyeaqmicqiky); } }
