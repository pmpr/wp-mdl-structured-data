<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto omqiayeucoioqoao; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\x65\x5f\x66\157\x6f\164\x65\x72"); omqiayeucoioqoao: parent::__construct($goiqeyeaqmicqiky); } }
