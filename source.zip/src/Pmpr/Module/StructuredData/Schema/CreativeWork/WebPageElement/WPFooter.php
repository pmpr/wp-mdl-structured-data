<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iwekmyyccgiyuecc; } $this->ckqasoiiqqiuueki("\43\163\x69\164\x65\137\x66\x6f\157\x74\145\x72"); iwekmyyccgiyuecc: parent::__construct($goiqeyeaqmicqiky); } }
