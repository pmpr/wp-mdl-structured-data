<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto coywmiyqgsweuiic; } $this->ckqasoiiqqiuueki("\43\163\151\164\145\137\146\157\x6f\x74\x65\162"); coywmiyqgsweuiic: parent::__construct($goiqeyeaqmicqiky); } }
