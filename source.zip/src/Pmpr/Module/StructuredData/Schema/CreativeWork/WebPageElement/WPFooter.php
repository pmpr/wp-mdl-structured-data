<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto omqiayeucoioqoao; } $this->ckqasoiiqqiuueki("\43\x73\151\164\145\x5f\146\x6f\x6f\x74\x65\x72"); omqiayeucoioqoao: parent::__construct($goiqeyeaqmicqiky); } }
