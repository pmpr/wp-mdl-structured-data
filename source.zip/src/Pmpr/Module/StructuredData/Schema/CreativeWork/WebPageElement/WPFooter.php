<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57cac70982             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iwekmyyccgiyuecc; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\145\137\146\x6f\157\x74\145\162"); iwekmyyccgiyuecc: parent::__construct($goiqeyeaqmicqiky); } }
