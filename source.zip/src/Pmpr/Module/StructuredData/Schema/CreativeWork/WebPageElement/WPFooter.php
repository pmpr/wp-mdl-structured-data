<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iwekmyyccgiyuecc; } $this->ckqasoiiqqiuueki("\43\x73\151\164\145\137\x66\157\157\164\x65\162"); iwekmyyccgiyuecc: parent::__construct($goiqeyeaqmicqiky); } }
