<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto egasokooagakisiy; } $this->ckqasoiiqqiuueki("\x23\163\x69\164\x65\x5f\146\157\157\164\145\x72"); egasokooagakisiy: parent::__construct($goiqeyeaqmicqiky); } }
