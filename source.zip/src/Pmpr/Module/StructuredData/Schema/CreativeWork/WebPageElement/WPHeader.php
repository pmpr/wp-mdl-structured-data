<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ycakugokkqkuqyiu; } $this->ckqasoiiqqiuueki("\43\163\x69\164\145\x5f\x68\145\x61\144\145\x72"); ycakugokkqkuqyiu: parent::__construct($goiqeyeaqmicqiky); } }
