<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto kecwuwwcwokuksyq; } $this->ckqasoiiqqiuueki("\x23\163\x69\x74\x65\x5f\x68\145\x61\x64\x65\x72"); kecwuwwcwokuksyq: parent::__construct($goiqeyeaqmicqiky); } }
