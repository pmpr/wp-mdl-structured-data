<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto acaqummmoyiemqss; } $this->ckqasoiiqqiuueki("\x23\163\151\164\145\137\x68\145\x61\144\x65\162"); acaqummmoyiemqss: parent::__construct($goiqeyeaqmicqiky); } }
