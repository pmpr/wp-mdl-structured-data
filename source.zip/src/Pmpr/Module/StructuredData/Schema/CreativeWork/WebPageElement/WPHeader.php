<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a583b359559             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ikqqskkqqwmwssoo; } $this->ckqasoiiqqiuueki("\x23\x73\x69\164\145\137\150\145\x61\x64\x65\x72"); ikqqskkqqwmwssoo: parent::__construct($goiqeyeaqmicqiky); } }
