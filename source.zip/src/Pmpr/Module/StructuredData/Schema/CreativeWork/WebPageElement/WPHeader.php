<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto oqugqwcyomiaaoqu; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\x65\x5f\x68\x65\141\x64\x65\162"); oqugqwcyomiaaoqu: parent::__construct($goiqeyeaqmicqiky); } }
