<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5eca5e30b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto usquiuuyiyqaeyiu; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\137\x68\x65\141\x64\x65\162"); usquiuuyiyqaeyiu: parent::__construct($goiqeyeaqmicqiky); } }
