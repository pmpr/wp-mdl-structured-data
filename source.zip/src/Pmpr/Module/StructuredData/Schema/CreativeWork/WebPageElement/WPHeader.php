<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto kecwuwwcwokuksyq; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\x65\x5f\x68\145\141\x64\x65\x72"); kecwuwwcwokuksyq: parent::__construct($goiqeyeaqmicqiky); } }
