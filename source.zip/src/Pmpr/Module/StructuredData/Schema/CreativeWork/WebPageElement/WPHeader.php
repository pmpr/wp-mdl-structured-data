<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ikqqskkqqwmwssoo; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\x68\145\141\144\145\162"); ikqqskkqqwmwssoo: parent::__construct($goiqeyeaqmicqiky); } }
