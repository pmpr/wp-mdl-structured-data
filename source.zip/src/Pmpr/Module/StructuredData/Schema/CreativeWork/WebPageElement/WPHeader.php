<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto kecwuwwcwokuksyq; } $this->ckqasoiiqqiuueki("\43\x73\x69\164\145\137\150\x65\141\144\145\162"); kecwuwwcwokuksyq: parent::__construct($goiqeyeaqmicqiky); } }
