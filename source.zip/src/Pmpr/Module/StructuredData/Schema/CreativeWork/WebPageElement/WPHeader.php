<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iqcogmsguwoikame; } $this->ckqasoiiqqiuueki("\43\163\x69\164\x65\x5f\x68\x65\x61\144\145\x72"); iqcogmsguwoikame: parent::__construct($goiqeyeaqmicqiky); } }
