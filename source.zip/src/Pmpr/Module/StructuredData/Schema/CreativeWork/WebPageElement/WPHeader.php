<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ycakugokkqkuqyiu; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\145\137\150\145\141\x64\145\x72"); ycakugokkqkuqyiu: parent::__construct($goiqeyeaqmicqiky); } }
