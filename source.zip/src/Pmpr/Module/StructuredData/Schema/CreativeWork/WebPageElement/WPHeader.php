<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto kecwuwwcwokuksyq; } $this->ckqasoiiqqiuueki("\43\163\151\x74\145\x5f\150\145\141\144\145\x72"); kecwuwwcwokuksyq: parent::__construct($goiqeyeaqmicqiky); } }
