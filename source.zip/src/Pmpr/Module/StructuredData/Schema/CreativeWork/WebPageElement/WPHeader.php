<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ikqqskkqqwmwssoo; } $this->ckqasoiiqqiuueki("\43\x73\x69\x74\x65\x5f\x68\145\x61\x64\x65\162"); ikqqskkqqwmwssoo: parent::__construct($goiqeyeaqmicqiky); } }
