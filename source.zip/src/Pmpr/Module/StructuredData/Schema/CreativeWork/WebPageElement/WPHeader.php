<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto kqgcyoscsusgoaqi; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\137\150\145\141\x64\x65\162"); kqgcyoscsusgoaqi: parent::__construct($goiqeyeaqmicqiky); } }
