<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto acaqummmoyiemqss; } $this->ckqasoiiqqiuueki("\x23\163\x69\x74\x65\x5f\150\145\x61\144\145\x72"); acaqummmoyiemqss: parent::__construct($goiqeyeaqmicqiky); } }
