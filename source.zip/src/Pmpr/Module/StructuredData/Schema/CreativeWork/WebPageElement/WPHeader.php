<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ikqqskkqqwmwssoo; } $this->ckqasoiiqqiuueki("\x23\x73\x69\x74\145\x5f\150\x65\x61\144\x65\x72"); ikqqskkqqwmwssoo: parent::__construct($goiqeyeaqmicqiky); } }
