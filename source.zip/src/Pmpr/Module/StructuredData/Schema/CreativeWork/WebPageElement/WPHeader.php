<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto wgewmqieuamsoayy; } $this->ckqasoiiqqiuueki("\43\163\151\164\x65\x5f\150\145\x61\x64\x65\x72"); wgewmqieuamsoayy: parent::__construct($goiqeyeaqmicqiky); } }
