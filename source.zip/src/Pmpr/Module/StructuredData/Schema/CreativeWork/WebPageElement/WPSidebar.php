<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ugqaaewwmkocwwgy; } $this->ckqasoiiqqiuueki("\x23\163\x69\164\145\137\163\x69\x64\x65\142\x61\162"); ugqaaewwmkocwwgy: parent::__construct($goiqeyeaqmicqiky); } }
