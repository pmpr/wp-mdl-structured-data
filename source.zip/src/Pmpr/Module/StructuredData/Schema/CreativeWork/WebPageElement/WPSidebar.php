<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto cmqucgoewuyieoyk; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\163\x69\144\145\142\x61\x72"); cmqucgoewuyieoyk: parent::__construct($goiqeyeaqmicqiky); } }
