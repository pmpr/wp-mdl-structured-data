<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae930db6b1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto qicwaskssogcokgm; } $this->ckqasoiiqqiuueki("\43\x73\151\164\x65\x5f\x73\x69\x64\x65\142\x61\162"); qicwaskssogcokgm: parent::__construct($goiqeyeaqmicqiky); } }
