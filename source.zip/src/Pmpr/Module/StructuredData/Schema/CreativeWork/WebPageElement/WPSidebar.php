<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ugqaaewwmkocwwgy; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\x73\151\144\145\142\x61\162"); ugqaaewwmkocwwgy: parent::__construct($goiqeyeaqmicqiky); } }
