<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto siqagquguiemuoku; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\x65\x5f\163\x69\144\x65\142\141\x72"); siqagquguiemuoku: parent::__construct($goiqeyeaqmicqiky); } }
