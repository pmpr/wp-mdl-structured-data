<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56fbc5c29             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto cmqucgoewuyieoyk; } $this->ckqasoiiqqiuueki("\x23\163\x69\x74\x65\137\163\151\x64\x65\142\x61\162"); cmqucgoewuyieoyk: parent::__construct($goiqeyeaqmicqiky); } }
