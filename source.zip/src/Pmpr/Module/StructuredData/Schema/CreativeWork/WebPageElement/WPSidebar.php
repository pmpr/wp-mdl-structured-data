<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto mswsoaimesegiiic; } $this->ckqasoiiqqiuueki("\43\x73\151\x74\x65\137\163\x69\144\x65\142\141\x72"); mswsoaimesegiiic: parent::__construct($goiqeyeaqmicqiky); } }
