<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto mswsoaimesegiiic; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\x5f\x73\151\x64\145\x62\141\162"); mswsoaimesegiiic: parent::__construct($goiqeyeaqmicqiky); } }
