<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a583b359559             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ogsaaqsaogcqiouy; } $this->ckqasoiiqqiuueki("\43\163\151\164\145\137\x73\x69\x64\x65\142\x61\x72"); ogsaaqsaogcqiouy: parent::__construct($goiqeyeaqmicqiky); } }
