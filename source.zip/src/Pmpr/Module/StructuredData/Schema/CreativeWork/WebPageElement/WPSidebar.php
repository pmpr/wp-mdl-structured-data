<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto wmmggowmigekyoso; } $this->ckqasoiiqqiuueki("\43\163\151\x74\145\137\x73\x69\x64\145\142\141\x72"); wmmggowmigekyoso: parent::__construct($goiqeyeaqmicqiky); } }
