<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ogsaaqsaogcqiouy; } $this->ckqasoiiqqiuueki("\43\163\x69\x74\145\137\163\151\144\145\x62\141\162"); ogsaaqsaogcqiouy: parent::__construct($goiqeyeaqmicqiky); } }
