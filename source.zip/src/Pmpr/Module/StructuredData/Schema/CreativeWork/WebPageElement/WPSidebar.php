<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto mswsoaimesegiiic; } $this->ckqasoiiqqiuueki("\43\163\x69\x74\145\137\x73\151\144\x65\142\141\162"); mswsoaimesegiiic: parent::__construct($goiqeyeaqmicqiky); } }
