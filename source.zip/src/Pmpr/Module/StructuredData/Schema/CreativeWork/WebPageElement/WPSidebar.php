<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ogsaaqsaogcqiouy; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\x65\137\163\x69\144\145\142\x61\162"); ogsaaqsaogcqiouy: parent::__construct($goiqeyeaqmicqiky); } }
