<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ogsaaqsaogcqiouy; } $this->ckqasoiiqqiuueki("\x23\163\x69\164\x65\x5f\x73\151\x64\x65\x62\x61\162"); ogsaaqsaogcqiouy: parent::__construct($goiqeyeaqmicqiky); } }
