<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e686aa44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ogsaaqsaogcqiouy; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\x65\x5f\x73\151\x64\x65\x62\141\162"); ogsaaqsaogcqiouy: parent::__construct($goiqeyeaqmicqiky); } }
