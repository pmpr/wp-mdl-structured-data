<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto wmmggowmigekyoso; } $this->ckqasoiiqqiuueki("\x23\x73\x69\x74\145\137\163\x69\144\x65\x62\141\162"); wmmggowmigekyoso: parent::__construct($goiqeyeaqmicqiky); } }
