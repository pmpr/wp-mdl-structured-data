<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ugqaaewwmkocwwgy; } $this->ckqasoiiqqiuueki("\x23\163\x69\164\x65\x5f\163\x69\144\x65\x62\141\x72"); ugqaaewwmkocwwgy: parent::__construct($goiqeyeaqmicqiky); } }
