<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto mswsoaimesegiiic; } $this->ckqasoiiqqiuueki("\43\x73\x69\x74\145\137\163\151\144\145\142\x61\x72"); mswsoaimesegiiic: parent::__construct($goiqeyeaqmicqiky); } }
