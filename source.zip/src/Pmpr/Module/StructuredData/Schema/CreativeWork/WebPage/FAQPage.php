<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Answer; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Question; class FAQPage extends WebPage { public function __construct(?array $oammesyieqmwuwyi = []) { if (!$oammesyieqmwuwyi) { goto iiiccouaaqsyikae; } foreach ($oammesyieqmwuwyi as $momcykaoccoymeig => $igqsaukqcqscimok) { $this->ikueqmmawsgmgyiu((new Question())->usuqmwksoeaayaig($igqsaukqcqscimok->question)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig))->ismaoyycqacwquag((new Answer())->kguaimkyumsuesem($igqsaukqcqscimok->answer)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig)))); wusciwkkckmqigms: } kqswcsysqawkcgye: $this->usuqmwksoeaayaig(__("\106\x41\121", PR__MDL__STRUCTURED_DATA)); iiiccouaaqsyikae: parent::__construct(false); } }
