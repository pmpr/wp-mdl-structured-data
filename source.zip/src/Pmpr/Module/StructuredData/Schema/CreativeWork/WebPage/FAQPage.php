<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Answer; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Question; class FAQPage extends WebPage { public function __construct(?array $oammesyieqmwuwyi = []) { if (!$oammesyieqmwuwyi) { goto wakmayaoqoskekqy; } foreach ($oammesyieqmwuwyi as $momcykaoccoymeig => $igqsaukqcqscimok) { $this->ikueqmmawsgmgyiu((new Question())->usuqmwksoeaayaig($igqsaukqcqscimok->question)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig))->ismaoyycqacwquag((new Answer())->kguaimkyumsuesem($igqsaukqcqscimok->answer)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig)))); wkeuuycukmuqiaom: } sggawugoykqcmsug: $this->usuqmwksoeaayaig(__("\106\x41\x51", PR__MDL__STRUCTURED_DATA)); wakmayaoqoskekqy: parent::__construct(false); } }
