<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Answer; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Question; class FAQPage extends WebPage { public function __construct(?array $oammesyieqmwuwyi = []) { if (!$oammesyieqmwuwyi) { goto qsygcycwieukkgwc; } foreach ($oammesyieqmwuwyi as $momcykaoccoymeig => $igqsaukqcqscimok) { $this->ikueqmmawsgmgyiu((new Question())->usuqmwksoeaayaig($igqsaukqcqscimok->question)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig))->ismaoyycqacwquag((new Answer())->kguaimkyumsuesem($igqsaukqcqscimok->answer)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig)))); umgaesggesswoaqe: } wwkgkaecgiwggcck: $this->usuqmwksoeaayaig(__("\x46\101\121", PR__MDL__STRUCTURED_DATA)); qsygcycwieukkgwc: parent::__construct(false); } }
