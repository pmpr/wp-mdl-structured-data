<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto gygawoqywkukmqee; } if ($this->suegwaomueaiseeo()) { goto oouoqimaaqcmccay; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); oouoqimaaqcmccay: if ($this->aakmagwggmkoiiyu()) { goto sycygoiaiqqageym; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); sycygoiaiqqageym: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); gygawoqywkukmqee: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
