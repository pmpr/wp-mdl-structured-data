<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto uaqackioaiqwcocy; } if ($this->suegwaomueaiseeo()) { goto sockeswygwcskeuq; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); sockeswygwcskeuq: if ($this->aakmagwggmkoiiyu()) { goto mkwkkmkgiqiamacc; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); mkwkkmkgiqiamacc: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); uaqackioaiqwcocy: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
