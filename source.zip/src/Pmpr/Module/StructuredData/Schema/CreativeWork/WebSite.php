<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto qgegkeomwscwwiuw; } if ($this->suegwaomueaiseeo()) { goto egasokooagakisiy; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); egasokooagakisiy: if ($this->aakmagwggmkoiiyu()) { goto kecwuwwcwokuksyq; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); kecwuwwcwokuksyq: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); qgegkeomwscwwiuw: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
