<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto eiawsoasmscmqswa; } if ($this->suegwaomueaiseeo()) { goto qmiwsequckckoaei; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); qmiwsequckckoaei: if ($this->aakmagwggmkoiiyu()) { goto goeoymmqqqeeoime; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); goeoymmqqqeeoime: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); eiawsoasmscmqswa: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
