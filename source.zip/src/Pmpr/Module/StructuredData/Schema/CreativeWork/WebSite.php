<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto oqugqwcyomiaaoqu; } if ($this->suegwaomueaiseeo()) { goto suswcqoyyqkkquuo; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); suswcqoyyqkkquuo: if ($this->aakmagwggmkoiiyu()) { goto eeqesooyqagwawae; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); eeqesooyqagwawae: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); oqugqwcyomiaaoqu: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
