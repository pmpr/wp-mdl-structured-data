<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4253969e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; use Pmpr\Common\Foundation\Manipulate\Post\ManipulatePost; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ousiuuwgwkiyikyq; } if ($this->suegwaomueaiseeo()) { goto miweggwqeiaeweia; } $this->eyqkogeiqauioamw(ManipulatePost::ycqquoiyyuesegsy()); miweggwqeiaeweia: if ($this->aakmagwggmkoiiyu()) { goto kqqiegkuqagcqsya; } $this->usuqmwksoeaayaig(ManipulatePost::qcgakseyaikigqco()); kqqiegkuqagcqsya: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); ousiuuwgwkiyikyq: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
