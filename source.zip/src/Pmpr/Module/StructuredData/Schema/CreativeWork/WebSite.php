<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56fbc5c29             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto foeeqckqsyockkak; } $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); if ($this->suegwaomueaiseeo()) { goto eeqesooyqagwawae; } $this->eyqkogeiqauioamw($seumokooiykcomco->ycqquoiyyuesegsy()); eeqesooyqagwawae: if ($this->aakmagwggmkoiiyu()) { goto oqugqwcyomiaaoqu; } $this->usuqmwksoeaayaig($seumokooiykcomco->qcgakseyaikigqco()); oqugqwcyomiaaoqu: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); foeeqckqsyockkak: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
