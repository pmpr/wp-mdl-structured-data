<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e686aa44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto isgwkwacoyimiauk; } $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); if ($this->suegwaomueaiseeo()) { goto uaqackioaiqwcocy; } $this->eyqkogeiqauioamw($seumokooiykcomco->ycqquoiyyuesegsy()); uaqackioaiqwcocy: if ($this->aakmagwggmkoiiyu()) { goto cscusseysqygsoiy; } $this->usuqmwksoeaayaig($seumokooiykcomco->qcgakseyaikigqco()); cscusseysqygsoiy: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); isgwkwacoyimiauk: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
