<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f9aa79f5da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Common\Foundation\Manipulate\Taxonomy\ManipulateTerm; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Category extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto yqykqysmiquwoasu; } $guwumyyyakswawas = ManipulateTerm::get(get_query_var("\143\x61\164")); $migiiksoiymissge = ManipulateTerm::qmgcisuuikgmqcsu($guwumyyyakswawas); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(single_cat_title('', false))->gucwmccyimoagwcm($this->caokeucsksukesyo()->owgcciayoweymuws()->kogyygyqqyqcioeg(strip_tags(category_description()), 1000))->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\102\154\157\x67")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($guwumyyyakswawas)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\x43\x61\164\x65\x67\x6f\x72\x79")); yqykqysmiquwoasu: parent::__construct($goiqeyeaqmicqiky); } }
