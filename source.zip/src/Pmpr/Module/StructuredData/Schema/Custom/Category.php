<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Category extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto mugqyyeayeyggqqk; } $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $guwumyyyakswawas = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\143\x61\164")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($guwumyyyakswawas); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo($ewsqcacamuomwagw->oykyuqgcqyasgeuw(false))->gucwmccyimoagwcm($ewsqcacamuomwagw->cwymaemaosauskko())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\x42\x6c\x6f\x67")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($guwumyyyakswawas)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\103\141\164\x65\147\157\x72\x79")); mugqyyeayeyggqqk: parent::__construct($goiqeyeaqmicqiky); } }
