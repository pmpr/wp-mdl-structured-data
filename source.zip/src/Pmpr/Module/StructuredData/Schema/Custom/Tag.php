<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a583b359559             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Tag extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto acsqgiuageaasiyy; } $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $scwiymciagumsuiw = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\x74\141\147\x5f\x69\144")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($scwiymciagumsuiw); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(sprintf(__("\124\x61\147\x20\x25\163", PR__MDL__STRUCTURED_DATA), $ewsqcacamuomwagw->ciiwwmaoykeuooma(false)))->gucwmccyimoagwcm($ewsqcacamuomwagw->sgqgswskkowaiqeq())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\x42\154\x6f\x67")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($scwiymciagumsuiw)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\x54\x61\147")); acsqgiuageaasiyy: parent::__construct($goiqeyeaqmicqiky); } }
