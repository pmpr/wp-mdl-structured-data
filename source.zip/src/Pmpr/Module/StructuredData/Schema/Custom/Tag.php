<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c2a7289             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Tag extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if ($goiqeyeaqmicqiky) { $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $scwiymciagumsuiw = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\x74\x61\147\137\x69\x64")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($scwiymciagumsuiw); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(sprintf(__("\124\x61\x67\x20\45\x73", PR__MDL__STRUCTURED_DATA), $ewsqcacamuomwagw->ciiwwmaoykeuooma(false)))->gucwmccyimoagwcm($ewsqcacamuomwagw->sgqgswskkowaiqeq())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\102\154\157\x67")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($scwiymciagumsuiw)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\x54\141\x67")); } parent::__construct($goiqeyeaqmicqiky); } }
