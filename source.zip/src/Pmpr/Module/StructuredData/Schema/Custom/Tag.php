<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Tag extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ykomgumacooyomsk; } $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $scwiymciagumsuiw = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\164\141\147\x5f\151\144")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($scwiymciagumsuiw); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(sprintf(__("\124\x61\x67\x20\45\x73", PR__MDL__STRUCTURED_DATA), $ewsqcacamuomwagw->ciiwwmaoykeuooma(false)))->gucwmccyimoagwcm($ewsqcacamuomwagw->sgqgswskkowaiqeq())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\x42\x6c\157\147")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($scwiymciagumsuiw)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\x54\141\147")); ykomgumacooyomsk: parent::__construct($goiqeyeaqmicqiky); } }
