<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Tag extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto acsqgiuageaasiyy; } $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $scwiymciagumsuiw = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\x74\x61\x67\137\151\144")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($scwiymciagumsuiw); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(sprintf(__("\x54\x61\x67\40\x25\x73", PR__MDL__STRUCTURED_DATA), $ewsqcacamuomwagw->ciiwwmaoykeuooma(false)))->gucwmccyimoagwcm($ewsqcacamuomwagw->sgqgswskkowaiqeq())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\x42\154\x6f\147")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($scwiymciagumsuiw)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\124\x61\147")); acsqgiuageaasiyy: parent::__construct($goiqeyeaqmicqiky); } }
