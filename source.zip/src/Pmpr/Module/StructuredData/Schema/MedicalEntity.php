<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5905a7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema; class MedicalEntity extends Thing { }
