<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e686aa44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Organization; class Project extends Organization { }
