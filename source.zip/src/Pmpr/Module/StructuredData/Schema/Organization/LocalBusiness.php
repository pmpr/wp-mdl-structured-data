<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Organization; class LocalBusiness extends Organization { }
