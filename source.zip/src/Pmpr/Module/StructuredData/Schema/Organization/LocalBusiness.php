<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5eca5e30b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Organization; class LocalBusiness extends Organization { }
