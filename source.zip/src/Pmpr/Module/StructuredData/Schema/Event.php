<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4bc5b7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema; class Event extends Thing { }
