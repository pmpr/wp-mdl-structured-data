<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4bc5b7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class MerchantReturnPolicy extends Intangible { protected ?string $returnPolicyCategory = null; protected $merchantReturnDays = null; public function wmqggaiuokouscoo(?string $iygkueuoesmaaagm) : self { $this->returnPolicyCategory = $iygkueuoesmaaagm; return $this; } public function mugakkeqwciygysw($usciuwoikmaogouy) : self { $this->merchantReturnDays = $usciuwoikmaogouy; return $this; } }
