<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { protected ?Enumeration $supersededBy = null; }
