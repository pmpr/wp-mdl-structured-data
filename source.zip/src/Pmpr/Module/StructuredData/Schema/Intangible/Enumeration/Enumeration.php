<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae930db6b1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { protected ?Enumeration $supersededBy = null; }
