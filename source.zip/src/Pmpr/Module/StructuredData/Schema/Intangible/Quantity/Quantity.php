<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Quantity; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Quantity extends Intangible { }
