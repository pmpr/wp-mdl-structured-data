<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Quantity; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Quantity extends Intangible { }
