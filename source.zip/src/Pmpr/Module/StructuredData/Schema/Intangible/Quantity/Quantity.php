<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02dae5e8c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Quantity; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Quantity extends Intangible { }
