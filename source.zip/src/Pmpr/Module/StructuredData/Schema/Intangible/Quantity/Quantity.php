<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4be803a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Quantity; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Quantity extends Intangible { }
