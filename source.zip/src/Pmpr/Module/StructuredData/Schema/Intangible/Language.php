<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5905a7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class Language extends Intangible { public function __construct($goiqeyeaqmicqiky = true) { $this->isGlobal = true; parent::__construct($goiqeyeaqmicqiky); } }
