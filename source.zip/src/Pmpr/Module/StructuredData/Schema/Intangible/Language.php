<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106b138870             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class Language extends Intangible { public function __construct() { $this->isGlobal = true; } }
