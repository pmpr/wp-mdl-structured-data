<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6d5edd15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue; class ShippingDeliveryTime extends StructuredValue { protected ?string $cutoffTime = null; protected ?QuantitativeValue $handlingTime = null; protected ?QuantitativeValue $transitTime = null; public function dkwsisskyykmuikc(?QuantitativeValue $wgskekacemwykgqg) : self { $this->transitTime = $wgskekacemwykgqg; return $this; } public function yeamiakowcakmaug(?QuantitativeValue $ugawmyqckwyqgcom) : self { $this->handlingTime = $ugawmyqckwyqgcom; return $this; } public function uauuyucwmawqsgqy(?string $emacwmmauqaguqyu) : self { $this->cutoffTime = $emacwmmauqaguqyu; return $this; } }
