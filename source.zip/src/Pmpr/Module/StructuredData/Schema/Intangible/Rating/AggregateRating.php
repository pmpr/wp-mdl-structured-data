<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4bc5b7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Rating; use Pmpr\Module\StructuredData\Schema\Thing; class AggregateRating extends Rating { protected ?int $reviewCount = null; protected ?int $ratingCount = null; protected ?Thing $itemReviewed = null; public function iiqgqiuayuwcueys() : ?Thing { return $this->itemReviewed; } public function mwyyceoeyyyqsiou(?Thing $ccqeayaegooouysc) { $this->itemReviewed = $ccqeayaegooouysc; return $this; } public function wemamaiqweumqsqo() : ?int { return $this->ratingCount; } public function aqgscesisoeawose(?int $yoecwgecueuaaueu) { $this->ratingCount = $yoecwgecueuaaueu; return $this; } public function mykgeucqkcaaakce() : ?int { return $this->reviewCount; } public function euaugmcwosukseuy(?int $geosgykscusuqmae) { $this->reviewCount = $geosgykscusuqmae; return $this; } }
