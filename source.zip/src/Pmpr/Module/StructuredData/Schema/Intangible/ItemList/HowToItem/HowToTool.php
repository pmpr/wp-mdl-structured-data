<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecae43b801             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\ItemList\HowToItem; class HowToTool extends HowToItem { protected ?string $requiredQuantity = null; public function kqsmaykmowogoaig() : ?string { return $this->requiredQuantity; } public function ikyimeskqesegsas(string $ikgeywmocweyiemi) : self { $this->requiredQuantity = $ikgeywmocweyiemi; return $this; } }
