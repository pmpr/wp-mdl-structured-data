<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b986710c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place\AdministrativeArea; use Pmpr\Module\StructuredData\Schema\Place\Place; class AdministrativeArea extends Place { }
