<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67ceddc0eb976             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place; use Pmpr\Module\StructuredData\Schema\Thing; class Place extends Thing { public function __construct() { $this->isGlobal = true; } }
