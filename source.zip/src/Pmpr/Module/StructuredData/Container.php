<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02dae5e8c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\StructuredData\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
