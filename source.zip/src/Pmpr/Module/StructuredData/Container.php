<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6d5edd15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\StructuredData\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
