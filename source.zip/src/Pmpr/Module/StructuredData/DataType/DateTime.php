<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e16942ebdb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class DateTime extends DataType { }
