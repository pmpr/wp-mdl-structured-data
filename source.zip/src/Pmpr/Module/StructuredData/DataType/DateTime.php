<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4064358703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class DateTime extends DataType { }
