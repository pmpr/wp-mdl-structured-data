<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Time extends DataType { }
