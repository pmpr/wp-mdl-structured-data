<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecae43b801             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Time extends DataType { }
