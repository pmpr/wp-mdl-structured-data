<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4bccd376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Date extends DataType { }
