<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57cac70982             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Date extends DataType { }
