<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58c4c1fb8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Boolean extends DataType { }
