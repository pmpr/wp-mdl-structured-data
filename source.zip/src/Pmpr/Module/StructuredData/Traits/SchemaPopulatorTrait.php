<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02dae5e8c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Traits; use Pmpr\Module\StructuredData\SchemaPopulator; trait SchemaPopulatorTrait { public function qukwsgoewmiomios() : SchemaPopulator { return SchemaPopulator::symcgieuakksimmu(); } }
