<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106b138870             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Traits; use Pmpr\Module\StructuredData\SchemaPopulator; trait SchemaPopulatorTrait { public function qukwsgoewmiomios() : SchemaPopulator { return SchemaPopulator::symcgieuakksimmu(); } }
