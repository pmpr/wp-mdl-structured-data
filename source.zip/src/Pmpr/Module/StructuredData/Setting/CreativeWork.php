<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Element\MetaBox; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CreativeWork extends Thing { const qggakygisakecymw = "\x68\157\x77\164\x6f\x5f\x70\x6c\141\143\x65\150\x6f\x6c\144\x65\x72"; public function aucimgwswmgaocae($ywoucyskcquysiwc) { $ywoucyskcquysiwc[] = MetaBox::sgsmqaoowiyocqaa($this->aakmagwggmkoiiyu() . "\x5f\164\141\142", __("\x43\162\145\x61\x74\151\x76\145\x20\127\x6f\162\153", PR__MDL__STRUCTURED_DATA))->sikqggwmmykuiymy(MetaBox::cgygmuguceeosoey($this->aakmagwggmkoiiyu() . "\x5f\150\x6f\167\164\157", __("\110\157\167\x20\x54\x6f", PR__MDL__STRUCTURED_DATA))->mkksewyosgeumwsa(MetaBox::kimoeccokowuaiic(self::qggakygisakecymw, __("\120\154\x61\143\x65\150\157\154\x64\145\162\40\x49\155\141\x67\x65\40\106\x6f\162\x20\x53\x74\x65\160\163", PR__MDL__STRUCTURED_DATA)))->saemoowcasogykak(IconInterface::cuagoyqymoegsqcm))->saemoowcasogykak(IconInterface::aysksyyosuiqaqge); return parent::aucimgwswmgaocae($ywoucyskcquysiwc); } }
