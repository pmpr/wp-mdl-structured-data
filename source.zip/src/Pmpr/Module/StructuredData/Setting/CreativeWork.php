<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6620edd58ef76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Element\MetaBox; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CreativeWork extends Thing { const qggakygisakecymw = "\150\157\167\x74\x6f\137\x70\154\x61\x63\145\150\157\154\144\145\162"; public function aucimgwswmgaocae($ywoucyskcquysiwc) { $ywoucyskcquysiwc[] = MetaBox::sgsmqaoowiyocqaa($this->aakmagwggmkoiiyu() . "\x5f\164\x61\142", __("\103\162\x65\x61\164\151\x76\x65\x20\127\157\x72\x6b", PR__MDL__STRUCTURED_DATA))->sikqggwmmykuiymy(MetaBox::cgygmuguceeosoey($this->aakmagwggmkoiiyu() . "\137\150\157\167\x74\x6f", __("\110\157\167\40\124\x6f", PR__MDL__STRUCTURED_DATA))->mkksewyosgeumwsa(MetaBox::kimoeccokowuaiic(self::qggakygisakecymw, __("\x50\x6c\x61\143\x65\x68\x6f\x6c\144\145\162\40\111\155\141\x67\x65\40\x46\x6f\162\x20\123\x74\x65\160\163", PR__MDL__STRUCTURED_DATA)))->saemoowcasogykak(IconInterface::cuagoyqymoegsqcm))->saemoowcasogykak(IconInterface::aysksyyosuiqaqge); return parent::aucimgwswmgaocae($ywoucyskcquysiwc); } }
