<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1d9314a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Element\MetaBox; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CreativeWork extends Thing { const qggakygisakecymw = "\150\x6f\x77\x74\x6f\137\x70\x6c\x61\x63\145\x68\x6f\x6c\144\x65\x72"; public function aucimgwswmgaocae($ywoucyskcquysiwc) { $ywoucyskcquysiwc[] = MetaBox::sgsmqaoowiyocqaa($this->aakmagwggmkoiiyu() . "\137\x74\141\x62", __("\x43\x72\145\x61\x74\151\166\x65\x20\x57\x6f\x72\x6b", PR__MDL__STRUCTURED_DATA))->sikqggwmmykuiymy(MetaBox::cgygmuguceeosoey($this->aakmagwggmkoiiyu() . "\137\x68\x6f\167\164\157", __("\110\x6f\x77\40\x54\157", PR__MDL__STRUCTURED_DATA))->mkksewyosgeumwsa(MetaBox::kimoeccokowuaiic(self::qggakygisakecymw, __("\120\x6c\x61\143\145\x68\157\x6c\144\x65\x72\x20\111\x6d\x61\147\x65\40\x46\x6f\162\x20\123\164\145\160\x73", PR__MDL__STRUCTURED_DATA)))->saemoowcasogykak(IconInterface::cuagoyqymoegsqcm))->saemoowcasogykak(IconInterface::aysksyyosuiqaqge); return parent::aucimgwswmgaocae($ywoucyskcquysiwc); } }
