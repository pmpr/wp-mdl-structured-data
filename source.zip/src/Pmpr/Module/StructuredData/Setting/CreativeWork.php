<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4651a433             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Element\MetaBox; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CreativeWork extends Thing { const qggakygisakecymw = "\150\x6f\167\164\x6f\x5f\x70\154\141\x63\145\150\157\x6c\144\x65\162"; public function aucimgwswmgaocae($ywoucyskcquysiwc) { $ywoucyskcquysiwc[] = MetaBox::sgsmqaoowiyocqaa($this->aakmagwggmkoiiyu() . "\x5f\x74\141\x62", __("\x43\x72\x65\x61\164\x69\x76\x65\40\x57\157\x72\153", PR__MDL__STRUCTURED_DATA))->sikqggwmmykuiymy(MetaBox::cgygmuguceeosoey($this->aakmagwggmkoiiyu() . "\x5f\x68\157\x77\164\x6f", __("\110\x6f\x77\40\124\x6f", PR__MDL__STRUCTURED_DATA))->mkksewyosgeumwsa(MetaBox::kimoeccokowuaiic(self::qggakygisakecymw, __("\120\154\141\x63\145\x68\157\154\144\145\x72\40\111\x6d\141\x67\145\40\x46\x6f\162\x20\123\164\x65\160\163", PR__MDL__STRUCTURED_DATA)))->saemoowcasogykak(IconInterface::cuagoyqymoegsqcm))->saemoowcasogykak(IconInterface::aysksyyosuiqaqge); return parent::aucimgwswmgaocae($ywoucyskcquysiwc); } }
