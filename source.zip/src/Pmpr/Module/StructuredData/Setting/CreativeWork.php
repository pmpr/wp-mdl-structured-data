<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336d97ac3c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\Element\MetaBox; use Pmpr\Common\Foundation\Interfaces\IconInterface; class CreativeWork extends Thing { const qggakygisakecymw = "\150\157\167\164\157\x5f\x70\x6c\x61\x63\x65\x68\x6f\154\x64\x65\162"; public function aucimgwswmgaocae($ywoucyskcquysiwc) { $ywoucyskcquysiwc[] = MetaBox::sgsmqaoowiyocqaa($this->aakmagwggmkoiiyu() . "\137\164\x61\x62", __("\x43\x72\145\141\164\151\166\x65\40\x57\x6f\x72\x6b", PR__MDL__STRUCTURED_DATA))->sikqggwmmykuiymy(MetaBox::cgygmuguceeosoey($this->aakmagwggmkoiiyu() . "\137\x68\157\167\164\x6f", __("\110\x6f\167\x20\x54\157", PR__MDL__STRUCTURED_DATA))->mkksewyosgeumwsa(MetaBox::kimoeccokowuaiic(self::qggakygisakecymw, __("\x50\x6c\141\x63\145\x68\157\x6c\x64\145\x72\40\x49\155\141\x67\145\x20\x46\157\162\x20\x53\x74\x65\160\163", PR__MDL__STRUCTURED_DATA)))->saemoowcasogykak(IconInterface::cuagoyqymoegsqcm))->saemoowcasogykak(IconInterface::aysksyyosuiqaqge); return parent::aucimgwswmgaocae($ywoucyskcquysiwc); } }
