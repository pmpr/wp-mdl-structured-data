<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870845a8127             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Module\StructuredData\Container; class Tabs extends Container { public function mameiwsayuyquoeq() { if (!Setting::symcgieuakksimmu()->eaiyegoagkgeowae()) { goto cecuyayqoioasumi; } Place::symcgieuakksimmu(); Intangible::symcgieuakksimmu(); CreativeWork::symcgieuakksimmu(); Organization::symcgieuakksimmu(); cecuyayqoioasumi: } }
