<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c61c7c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Module\StructuredData\Container; class Tabs extends Container { public function mameiwsayuyquoeq() { if (!Setting::symcgieuakksimmu()->eaiyegoagkgeowae()) { goto cmqucgoewuyieoyk; } Place::symcgieuakksimmu(); Intangible::symcgieuakksimmu(); CreativeWork::symcgieuakksimmu(); Organization::symcgieuakksimmu(); cmqucgoewuyieoyk: } }
