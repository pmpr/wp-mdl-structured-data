<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661f8d975be2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Module\StructuredData\Container; class Tabs extends Container { public function mameiwsayuyquoeq() { if (!Setting::symcgieuakksimmu()->eaiyegoagkgeowae()) { goto suqcsgaosywaauuu; } Place::symcgieuakksimmu(); Intangible::symcgieuakksimmu(); CreativeWork::symcgieuakksimmu(); Organization::symcgieuakksimmu(); suqcsgaosywaauuu: } }
