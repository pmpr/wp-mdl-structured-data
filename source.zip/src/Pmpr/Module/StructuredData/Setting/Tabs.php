<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011231e1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Module\StructuredData\Container; class Tabs extends Container { public function mameiwsayuyquoeq() { if (!Setting::symcgieuakksimmu()->eaiyegoagkgeowae()) { goto cecuyayqoioasumi; } Place::symcgieuakksimmu(); Intangible::symcgieuakksimmu(); CreativeWork::symcgieuakksimmu(); Organization::symcgieuakksimmu(); cecuyayqoioasumi: } }
