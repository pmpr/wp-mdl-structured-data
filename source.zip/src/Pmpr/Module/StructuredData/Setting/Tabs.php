<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Module\StructuredData\Container; class Tabs extends Container { public function mameiwsayuyquoeq() { if (!Setting::symcgieuakksimmu()->eaiyegoagkgeowae()) { goto kqswcsysqawkcgye; } Place::symcgieuakksimmu(); Intangible::symcgieuakksimmu(); CreativeWork::symcgieuakksimmu(); Organization::symcgieuakksimmu(); kqswcsysqawkcgye: } }
