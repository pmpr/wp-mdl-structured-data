<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069afd91cf9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\SettingTab; class Thing extends SettingTab { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
