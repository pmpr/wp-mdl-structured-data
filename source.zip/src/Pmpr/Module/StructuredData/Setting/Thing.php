<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c0f478a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\SettingTab; class Thing extends SettingTab { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
