<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66243f5fe1f6c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Setting; use Pmpr\Common\Foundation\FormMaker\Admin\SettingTab; class Thing extends SettingTab { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
