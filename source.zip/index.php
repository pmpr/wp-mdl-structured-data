<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e16942ebdb4             |
    |_______________________________________|
*/
 use Pmpr\Module\StructuredData\StructuredData; StructuredData::symcgieuakksimmu();
