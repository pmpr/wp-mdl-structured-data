<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c1e8366             |
    |_______________________________________|
*/
 use Pmpr\Module\StructuredData\StructuredData; StructuredData::symcgieuakksimmu();
